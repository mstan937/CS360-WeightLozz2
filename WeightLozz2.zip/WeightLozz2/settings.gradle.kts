// settings.gradle.kts

pluginManagement {
    // Define flutterSdkPath using Kotlin's syntax
    // Define flutterSdkPath using Gradle's built-in properties
    val flutterSdkPath: String by settings

    // Include the Flutter tools Gradle build
    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    id("com.android.application") version "7.3.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false

    // START: FlutterFire Configuration
    id("com.google.gms.google-services") version "4.4.2" apply false
    id("com.google.firebase.firebase-perf") version "1.4.2" apply false
    id("com.google.firebase.crashlytics") version "3.0.2" apply false
    // END: FlutterFire Configuration
}

rootProject.name = "WeightLozz2"
include(":app")
