// build.gradle.kts (Project-Level)

buildscript {
    // Define version variables using extra properties
    extra["kotlin_version"] = "1.8.21"
    extra["compose_version"] = "1.4.0"
    extra["room_version"] = "2.5.1" // If not already defined

    repositories {
        google()
        mavenCentral()
    }

    dependencies {
        classpath(libs.gradle)
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:${property("kotlin_version")}")
        classpath(libs.google.services.v4315) // Firebase
        classpath (libs.google.services.v440)
        classpath(libs.com.google.devtools.ksp.gradle.plugin) // KSP Plugin
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

tasks.register<Delete>("clean") {
    delete(layout.buildDirectory)
}
