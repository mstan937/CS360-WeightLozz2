package com.example.weightlozz2.userinterfac

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.charts.LineChart
import androidx.compose.ui.viewinterop.AndroidView
import com.example.weightlozz2.model.WeightEntry
import java.util.*

@Composable
fun WeightChart(
    weightEntries: List<WeightEntry> = emptyList()
) {
    val sortedEntries = remember(weightEntries) { weightEntries.sortedBy { it.date } }
    val entries = sortedEntries.mapIndexed { index, weightEntry ->
        Entry(index.toFloat(), weightEntry.weight)
    }

    AndroidView(
        factory = { context ->
            LineChart(context).apply {
                setTouchEnabled(true)
                setPinchZoom(true)
                description = Description().apply { text = "Weight Over Time" }

                val lineDataSet = LineDataSet(entries, "Weight (kg)").apply {
                    color = android.graphics.Color.BLUE
                    valueTextColor = android.graphics.Color.BLACK
                    lineWidth = 2f
                    circleRadius = 4f
                    setDrawCircleHole(false)
                    setDrawValues(false)
                }

                val lineData = LineData(lineDataSet)
                data = lineData

                invalidate()
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
    )
}
