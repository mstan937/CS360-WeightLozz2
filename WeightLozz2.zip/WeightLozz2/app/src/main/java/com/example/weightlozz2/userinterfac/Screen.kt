package com.example.weightlozz2.userinterfac

sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object SignUp : Screen("sign_up")
    data object Home : Screen("home")
    data object AddEntry : Screen("add_entry")
    data object WeightChart : Screen("weight_chart")
}