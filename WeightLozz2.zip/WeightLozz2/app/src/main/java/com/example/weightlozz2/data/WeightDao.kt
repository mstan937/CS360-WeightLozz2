package com.example.weightlozz2.data

// WeightDao.kt


import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.weightlozz.model.WeightEntry

@Dao
interface WeightDao {
    @Query("SELECT * FROM weight_entries ORDER BY date DESC")
    fun getAllEntries(): LiveData<List<WeightEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: WeightEntry)

    @Delete
    suspend fun delete(entry: WeightEntry)
}
