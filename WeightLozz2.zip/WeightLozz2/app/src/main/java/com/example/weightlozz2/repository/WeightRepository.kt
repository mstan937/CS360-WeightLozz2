package com.example.weightlozz2.repository
// File: app/src/main/java/com/example/weightlozz2/repository/WeightRepositoryImpl.kt

import com.example.weightlozz2.data.WeightDao
import com.example.weightlozz2.model.WeightEntry
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WeightRepositoryImpl @Inject constructor(
    private val weightDao: WeightDao
) : WeightRepository {

    override fun getAllWeightEntries(): Flow<List<WeightEntry>> = weightDao.getAllEntries()

    override suspend fun insertWeightEntry(entry: WeightEntry) = weightDao.insertEntry(entry)

    override suspend fun deleteWeightEntry(entry: WeightEntry) = weightDao.deleteEntry(entry)
}

