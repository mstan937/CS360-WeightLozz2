package com.example.weightlozz2.userinterfac

// HomeScreen.kt (modified)


import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.weightlozz.model.WeightEntry
import com.example.weightlozz.ui.components.WeightChart
import com.example.weightlozz.viewmodel.WeightViewModel

@Composable
fun HomeScreen(navController: NavController, weightViewModel: WeightViewModel = viewModel()) {
    val weightEntries by weightViewModel.allEntries.observeAsState(emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("WeightLozz") },
                actions = {
                    IconButton(onClick = { /* Implement Settings if needed */ }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("addEntry") }) {
                Icon(Icons.Default.Add, contentDescription = "Add Entry")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (weightEntries.isNotEmpty()) {
                WeightChart(
                    weightEntries = weightEntries.reversed(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            if (weightEntries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text("No entries yet. Add your first weight entry!")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(weightEntries) { entry ->
                        WeightEntryItem(entry)
                    }
                }
            }
        }
    }
}
