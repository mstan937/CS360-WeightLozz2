package com.example.weightlozz2;

import android.app.Application;

public class MyApplication extends Application {
}
