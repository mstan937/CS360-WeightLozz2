package com.example.weightlozz2.navigation


import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.weightlozz2.ui.userinterface.*

@Composable
fun NavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route,
        modifier = modifier
    ) {
        composable(Screen.Login.route) {
            LoginScreen(onNavigateToSignUp = {
                navController.navigate(Screen.SignUp.route)
            }, onLoginSuccess = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Login.route) { inclusive = true }
                }
            })
        }
        composable(Screen.SignUp.route) {
            SignUpScreen(onNavigateToLogin = {
                navController.navigate(Screen.Login.route) {
                    popUpTo(Screen.SignUp.route) { inclusive = true }
                }
            }, onSignUpSuccess = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.SignUp.route) { inclusive = true }
                }
            })
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToAddEntry = {
                    navController.navigate(Screen.AddEntry.route)
                },
                onLogout = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.Home.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.AddEntry.route) {
            AddEntryScreen(onEntryAdded = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.AddEntry.route) { inclusive = true }
                }
            })
        }
        composable(Screen.WeightChart.route) {
            WeightChart()
        }
    }
}
