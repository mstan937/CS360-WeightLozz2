package com.example.weightlozz2.viewmodel

