package com.example.weightlozz2.userinterfac

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.weightlozz2.viewmodel.WeightViewModel

@Composable
fun AddEntryScreen(
    onEntryAdded: () -> Unit,
    viewModel: WeightViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    var weightInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Add Weight Entry") })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = weightInput,
                onValueChange = { weightInput = it },
                label = { Text("Weight (kg)") },
                keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    val weight = weightInput.toFloatOrNull()
                    if (weight == null || weight <= 0) {
                        errorMessage = "Please enter a valid weight."
                        return@Button
                    }
                    viewModel.addWeightEntry(weight)
                    onEntryAdded()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Entry")
            }
            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage ?: "",
                    color = MaterialTheme.colors.error,
                    style = MaterialTheme.typography.body2
                )
            }
        }
    }
}
