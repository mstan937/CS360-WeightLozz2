// File: app/build.gradle.kts

plugins {
    id("com.android.application")
    kotlin("android")
    kotlin("kapt") // For annotation processing
    id("dagger.hilt.android.plugin") // Hilt plugin
    id("com.google.gms.google-services") // Firebase
    id("com.google.firebase.crashlytics") // Firebase Crashlytics
    id("com.google.firebase.firebase-perf") // Firebase Performance Monitoring
}

android {
    namespace = "com.example.weightlozz2"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.weightlozz2"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.4.0"
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Hilt dependencies
    implementation(libs.hilt.android)
    implementation(libs.androidx.room.common)
    implementation(libs.androidx.room.common.jvm)
    kapt(libs.hilt.android.compiler)

    // Room dependencies
    implementation(libs.room.runtime.v251)
    kapt(libs.room.compiler.v251)
    implementation(libs.room.ktx.v251)

    // Kotlin and Coroutines
    implementation(libs.kotlin.stdlib)
    implementation(libs.kotlinx.coroutines.android)

    // Jetpack Compose
    implementation(libs.ui)
    implementation(libs.androidx.material)
    implementation(libs.ui.tooling.preview)
    debugImplementation(libs.ui.tooling)

    // ViewModel and LiveData
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.livedata.ktx)

    // Navigation Component for Compose
    implementation(libs.androidx.navigation.compose)

    // Material Design
    implementation(libs.google.material.v190)

    // MPAndroidChart
    implementation(libs.mpandroidchart)

    // Firebase Authentication
    implementation(platform(libs.firebase.bom))
    implementation(libs.com.google.firebase.firebase.auth.ktx3)

    // Testing Dependencies
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit.v115)
    androidTestImplementation(libs.androidx.espresso.core.v351)
    androidTestImplementation(libs.ui.test.junit4)
}
