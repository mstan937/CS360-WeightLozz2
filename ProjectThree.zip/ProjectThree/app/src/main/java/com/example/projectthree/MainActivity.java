package com.example.projectthree;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private DatabaseHelper dbHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI elements
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Set up login button listener
        findViewById(R.id.btnLogin).setOnClickListener(this::onClick);

        // Set up registration button listener
        findViewById(R.id.btnRegister).setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            } else if (dbHelper.insertUser(username, password)) {
                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Registration Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void onClick(View v) {
        String username = etUsername.getText().toString().trim(); // Ensure trimming
        String password = etPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
        } else if (dbHelper.authenticateUser(username, password)) {
            startActivity(new Intent(this, DataGridActivity.class)); // Navigate to DataGridActivity
        } else {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();

            public class MyClass {

                public static void main(String[] args) { // This is the main method
                    int x = 5; // Declaration and initialization of x
                    System.out.println(x); // Printing the value of x
                }
            }
        }
    }
}
